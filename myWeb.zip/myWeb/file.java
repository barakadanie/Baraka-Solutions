import java.sql.*;
public class file()
{
    public static void main(String[] args)
    {
        System.out.println("hello word");
    }
}